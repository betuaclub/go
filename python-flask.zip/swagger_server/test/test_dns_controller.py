# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.dnsdomain_records_body import DnsdomainRecordsBody  # noqa: E501
from swagger_server.models.dnsdomain_soa_body import DnsdomainSoaBody  # noqa: E501
from swagger_server.models.domains_body import DomainsBody  # noqa: E501
from swagger_server.models.domains_dnsdomain_body import DomainsDnsdomainBody  # noqa: E501
from swagger_server.models.inline_response20024 import InlineResponse20024  # noqa: E501
from swagger_server.models.inline_response20025 import InlineResponse20025  # noqa: E501
from swagger_server.models.inline_response20026 import InlineResponse20026  # noqa: E501
from swagger_server.models.inline_response20027 import InlineResponse20027  # noqa: E501
from swagger_server.models.inline_response20028 import InlineResponse20028  # noqa: E501
from swagger_server.models.inline_response2014 import InlineResponse2014  # noqa: E501
from swagger_server.models.records_recordid_body import RecordsRecordidBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestDnsController(BaseTestCase):
    """DnsController integration test stubs"""

    def test_create_dns_domain(self):
        """Test case for create_dns_domain

        Create DNS Domain
        """
        body = DomainsBody()
        response = self.client.open(
            '/v2/domains',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_dns_domain_record(self):
        """Test case for create_dns_domain_record

        Create Record
        """
        body = DnsdomainRecordsBody()
        response = self.client.open(
            '/v2/domains/{dns-domain}/records'.format(dns_domain='dns_domain_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_dns_domain(self):
        """Test case for delete_dns_domain

        Delete Domain
        """
        response = self.client.open(
            '/v2/domains/{dns-domain}'.format(dns_domain='dns_domain_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_dns_domain_record(self):
        """Test case for delete_dns_domain_record

        Delete Record
        """
        response = self.client.open(
            '/v2/domains/{dns-domain}/records/{record-id}'.format(dns_domain='dns_domain_example', record_id='record_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_dns_domain(self):
        """Test case for get_dns_domain

        Get DNS Domain
        """
        response = self.client.open(
            '/v2/domains/{dns-domain}'.format(dns_domain='dns_domain_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_dns_domain_dnssec(self):
        """Test case for get_dns_domain_dnssec

        Get DNSSec Info
        """
        response = self.client.open(
            '/v2/domains/{dns-domain}/dnssec'.format(dns_domain='dns_domain_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_dns_domain_record(self):
        """Test case for get_dns_domain_record

        Get Record
        """
        response = self.client.open(
            '/v2/domains/{dns-domain}/records/{record-id}'.format(dns_domain='dns_domain_example', record_id='record_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_dns_domain_soa(self):
        """Test case for get_dns_domain_soa

        Get SOA information
        """
        response = self.client.open(
            '/v2/domains/{dns-domain}/soa'.format(dns_domain='dns_domain_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_dns_domain_records(self):
        """Test case for list_dns_domain_records

        List Records
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/domains/{dns-domain}/records'.format(dns_domain='dns_domain_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_dns_domains(self):
        """Test case for list_dns_domains

        List DNS Domains
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/domains',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_dns_domain(self):
        """Test case for update_dns_domain

        Update a DNS Domain
        """
        body = DomainsDnsdomainBody()
        response = self.client.open(
            '/v2/domains/{dns-domain}'.format(dns_domain='dns_domain_example'),
            method='PUT',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_dns_domain_record(self):
        """Test case for update_dns_domain_record

        Update Record
        """
        body = RecordsRecordidBody()
        response = self.client.open(
            '/v2/domains/{dns-domain}/records/{record-id}'.format(dns_domain='dns_domain_example', record_id='record_id_example'),
            method='PATCH',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_dns_domain_soa(self):
        """Test case for update_dns_domain_soa

        Update SOA information
        """
        body = DnsdomainSoaBody()
        response = self.client.open(
            '/v2/domains/{dns-domain}/soa'.format(dns_domain='dns_domain_example'),
            method='PATCH',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
