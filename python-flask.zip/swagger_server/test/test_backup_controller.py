# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response20016 import InlineResponse20016  # noqa: E501
from swagger_server.models.inline_response20049 import InlineResponse20049  # noqa: E501
from swagger_server.test import BaseTestCase


class TestBackupController(BaseTestCase):
    """BackupController integration test stubs"""

    def test_get_backup(self):
        """Test case for get_backup

        Get a Backup
        """
        response = self.client.open(
            '/v2/backups/{backup-id}'.format(backup_id='backup_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_backups(self):
        """Test case for list_backups

        List Backups
        """
        query_string = [('instance_id', 'instance_id_example'),
                        ('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/backups',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
