# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response20060 import InlineResponse20060  # noqa: E501
from swagger_server.models.inline_response20061 import InlineResponse20061  # noqa: E501
from swagger_server.models.inline_response20062 import InlineResponse20062  # noqa: E501
from swagger_server.models.inline_response20063 import InlineResponse20063  # noqa: E501
from swagger_server.test import BaseTestCase


class TestBillingController(BaseTestCase):
    """BillingController integration test stubs"""

    def test_get_invoice(self):
        """Test case for get_invoice

        Get Invoice
        """
        response = self.client.open(
            '/v2/billing/invoices/{invoice-id}'.format(invoice_id='invoice_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_invoice_items(self):
        """Test case for get_invoice_items

        Get Invoice Items
        """
        response = self.client.open(
            '/v2/billing/invoices/{invoice-id}/items'.format(invoice_id='invoice_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_billing_history(self):
        """Test case for list_billing_history

        List Billing History
        """
        response = self.client.open(
            '/v2/billing/history',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_invoices(self):
        """Test case for list_invoices

        List Invoices
        """
        response = self.client.open(
            '/v2/billing/invoices',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
