# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response20022 import InlineResponse20022  # noqa: E501
from swagger_server.models.inline_response20023 import InlineResponse20023  # noqa: E501
from swagger_server.models.inline_response2013 import InlineResponse2013  # noqa: E501
from swagger_server.models.inline_response2021 import InlineResponse2021  # noqa: E501
from swagger_server.models.objectstorage_body import ObjectstorageBody  # noqa: E501
from swagger_server.models.objectstorage_objectstorageid_body import ObjectstorageObjectstorageidBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestS3Controller(BaseTestCase):
    """S3Controller integration test stubs"""

    def test_create_object_storage(self):
        """Test case for create_object_storage

        Create Object Storage
        """
        body = ObjectstorageBody()
        response = self.client.open(
            '/v2/object-storage',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_object_storage(self):
        """Test case for delete_object_storage

        Delete Object Storage
        """
        response = self.client.open(
            '/v2/object-storage/{object-storage-id}'.format(object_storage_id='object_storage_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_object_storage(self):
        """Test case for get_object_storage

        Get Object Storage
        """
        response = self.client.open(
            '/v2/object-storage/{object-storage-id}'.format(object_storage_id='object_storage_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_object_storage_clusters(self):
        """Test case for list_object_storage_clusters

        Get All Clusters
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/object-storage/clusters',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_object_storages(self):
        """Test case for list_object_storages

        List Object Storages
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/object-storage',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_regenerate_object_storage_keys(self):
        """Test case for regenerate_object_storage_keys

        Regenerate Object Storage Keys
        """
        response = self.client.open(
            '/v2/object-storage/{object-storage-id}/regenerate-keys'.format(object_storage_id='object_storage_id_example'),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_object_storage(self):
        """Test case for update_object_storage

        Update Object Storage
        """
        body = ObjectstorageObjectstorageidBody()
        response = self.client.open(
            '/v2/object-storage/{object-storage-id}'.format(object_storage_id='object_storage_id_example'),
            method='PUT',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
