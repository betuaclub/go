# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.blockid_attach_body import BlockidAttachBody  # noqa: E501
from swagger_server.models.blockid_detach_body import BlockidDetachBody  # noqa: E501
from swagger_server.models.blocks_blockid_body import BlocksBlockidBody  # noqa: E501
from swagger_server.models.blocks_body import BlocksBody  # noqa: E501
from swagger_server.models.inline_response20017 import InlineResponse20017  # noqa: E501
from swagger_server.models.inline_response202 import InlineResponse202  # noqa: E501
from swagger_server.test import BaseTestCase


class TestBlockController(BaseTestCase):
    """BlockController integration test stubs"""

    def test_attach_block(self):
        """Test case for attach_block

        Attach Block Storage
        """
        body = BlockidAttachBody()
        response = self.client.open(
            '/v2/blocks/{block-id}/attach'.format(block_id='block_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_block(self):
        """Test case for create_block

        Create Block Storage
        """
        body = BlocksBody()
        response = self.client.open(
            '/v2/blocks',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_block(self):
        """Test case for delete_block

        Delete Block Storage
        """
        response = self.client.open(
            '/v2/blocks/{block-id}'.format(block_id='block_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_detach_block(self):
        """Test case for detach_block

        Detach Block Storage
        """
        body = BlockidDetachBody()
        response = self.client.open(
            '/v2/blocks/{block-id}/detach'.format(block_id='block_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_block(self):
        """Test case for get_block

        Get Block Storage
        """
        response = self.client.open(
            '/v2/blocks/{block-id}'.format(block_id='block_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_blocks(self):
        """Test case for list_blocks

        List Block storages
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/blocks',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_block(self):
        """Test case for update_block

        Update Block Storage
        """
        body = BlocksBlockidBody()
        response = self.client.open(
            '/v2/blocks/{block-id}'.format(block_id='block_id_example'),
            method='PATCH',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
