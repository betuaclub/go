# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response20029 import InlineResponse20029  # noqa: E501
from swagger_server.models.inline_response20030 import InlineResponse20030  # noqa: E501
from swagger_server.test import BaseTestCase


class TestRegionController(BaseTestCase):
    """RegionController integration test stubs"""

    def test_list_available_plans_region(self):
        """Test case for list_available_plans_region

        List available plans in region
        """
        query_string = [('type', 'type_example')]
        response = self.client.open(
            '/v2/regions/{region-id}/availability'.format(region_id='region_id_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_regions(self):
        """Test case for list_regions

        List Regions
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/regions',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
