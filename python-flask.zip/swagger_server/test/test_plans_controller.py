# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response20034 import InlineResponse20034  # noqa: E501
from swagger_server.models.inline_response20035 import InlineResponse20035  # noqa: E501
from swagger_server.test import BaseTestCase


class TestPlansController(BaseTestCase):
    """PlansController integration test stubs"""

    def test_list_metal_plans(self):
        """Test case for list_metal_plans

        List Bare Metal Plans
        """
        query_string = [('per_page', 'per_page_example'),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/plans-metal',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_plans(self):
        """Test case for list_plans

        List Plans
        """
        query_string = [('type', 'type_example'),
                        ('per_page', 56),
                        ('cursor', 'cursor_example'),
                        ('os', 'os_example')]
        response = self.client.open(
            '/v2/plans',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
