# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response200 import InlineResponse200  # noqa: E501
from swagger_server.models.inline_response2001 import InlineResponse2001  # noqa: E501
from swagger_server.models.privatenetworks_body import PrivatenetworksBody  # noqa: E501
from swagger_server.models.privatenetworks_networkid_body import PrivatenetworksNetworkidBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestPrivateNetworksController(BaseTestCase):
    """PrivateNetworksController integration test stubs"""

    def test_create_network(self):
        """Test case for create_network

        Create a Private Network
        """
        body = PrivatenetworksBody()
        response = self.client.open(
            '/v2/private-networks',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_network(self):
        """Test case for delete_network

        Delete a private network
        """
        response = self.client.open(
            '/v2/private-networks/{network-id}'.format(network_id='network_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_network(self):
        """Test case for get_network

        Get a private network
        """
        response = self.client.open(
            '/v2/private-networks/{network-id}'.format(network_id='network_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_networks(self):
        """Test case for list_networks

        List Private Networks
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/private-networks',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_network(self):
        """Test case for update_network

        Update a Private Network
        """
        body = PrivatenetworksNetworkidBody()
        response = self.client.open(
            '/v2/private-networks/{network-id}'.format(network_id='network_id_example'),
            method='PUT',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
