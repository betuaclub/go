# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response20010 import InlineResponse20010  # noqa: E501
from swagger_server.models.inline_response2009 import InlineResponse2009  # noqa: E501
from swagger_server.models.snapshots_body import SnapshotsBody  # noqa: E501
from swagger_server.models.snapshots_createfromurl_body import SnapshotsCreatefromurlBody  # noqa: E501
from swagger_server.models.snapshots_snapshotid_body import SnapshotsSnapshotidBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestSnapshotController(BaseTestCase):
    """SnapshotController integration test stubs"""

    def test_create_snapshot(self):
        """Test case for create_snapshot

        Create Snapshot
        """
        body = SnapshotsBody()
        response = self.client.open(
            '/v2/snapshots',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_snapshot_create_from_url(self):
        """Test case for create_snapshot_create_from_url

        Create Snapshot from URL
        """
        body = SnapshotsCreatefromurlBody()
        response = self.client.open(
            '/v2/snapshots/create-from-url',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_snapshot(self):
        """Test case for delete_snapshot

        Delete Snapshot
        """
        response = self.client.open(
            '/v2/snapshots/{snapshot-id}'.format(snapshot_id='snapshot_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_snapshot(self):
        """Test case for get_snapshot

        Get Snapshot
        """
        response = self.client.open(
            '/v2/snapshots/{snapshot-id}'.format(snapshot_id='snapshot_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_snapshots(self):
        """Test case for list_snapshots

        List Snapshots
        """
        query_string = [('description', 'description_example'),
                        ('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/snapshots',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_put_snapshots_snapshot_id(self):
        """Test case for put_snapshots_snapshot_id

        Update Snapshot
        """
        body = SnapshotsSnapshotidBody()
        response = self.client.open(
            '/v2/snapshots/{snapshot-id}'.format(snapshot_id='snapshot_id_example'),
            method='PUT',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
