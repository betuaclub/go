# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response20038 import InlineResponse20038  # noqa: E501
from swagger_server.models.inline_response20039 import InlineResponse20039  # noqa: E501
from swagger_server.models.inline_response20040 import InlineResponse20040  # noqa: E501
from swagger_server.models.inline_response20042 import InlineResponse20042  # noqa: E501
from swagger_server.models.inline_response20043 import InlineResponse20043  # noqa: E501
from swagger_server.models.inline_response20044 import InlineResponse20044  # noqa: E501
from swagger_server.models.inline_response20045 import InlineResponse20045  # noqa: E501
from swagger_server.models.inline_response20046 import InlineResponse20046  # noqa: E501
from swagger_server.models.inline_response20047 import InlineResponse20047  # noqa: E501
from swagger_server.models.inline_response20048 import InlineResponse20048  # noqa: E501
from swagger_server.models.inline_response20050 import InlineResponse20050  # noqa: E501
from swagger_server.models.inline_response20051 import InlineResponse20051  # noqa: E501
from swagger_server.models.inline_response2024 import InlineResponse2024  # noqa: E501
from swagger_server.models.inline_response2025 import InlineResponse2025  # noqa: E501
from swagger_server.models.inline_response2026 import InlineResponse2026  # noqa: E501
from swagger_server.models.inline_response2027 import InlineResponse2027  # noqa: E501
from swagger_server.models.instanceid_backupschedule_body import InstanceidBackupscheduleBody  # noqa: E501
from swagger_server.models.instanceid_ipv4_body import InstanceidIpv4Body  # noqa: E501
from swagger_server.models.instanceid_reinstall_body import InstanceidReinstallBody  # noqa: E501
from swagger_server.models.instanceid_restore_body import InstanceidRestoreBody  # noqa: E501
from swagger_server.models.instances_body import InstancesBody  # noqa: E501
from swagger_server.models.instances_halt_body import InstancesHaltBody  # noqa: E501
from swagger_server.models.instances_instanceid_body import InstancesInstanceidBody  # noqa: E501
from swagger_server.models.instances_reboot_body import InstancesRebootBody  # noqa: E501
from swagger_server.models.instances_start_body import InstancesStartBody  # noqa: E501
from swagger_server.models.ipv4_reverse_body import Ipv4ReverseBody  # noqa: E501
from swagger_server.models.ipv6_reverse_body import Ipv6ReverseBody  # noqa: E501
from swagger_server.models.iso_attach_body import IsoAttachBody  # noqa: E501
from swagger_server.models.privatenetworks_attach_body import PrivatenetworksAttachBody  # noqa: E501
from swagger_server.models.privatenetworks_detach_body import PrivatenetworksDetachBody  # noqa: E501
from swagger_server.models.reverse_default_body import ReverseDefaultBody  # noqa: E501
from swagger_server.models.vpcs_attach_body import VpcsAttachBody  # noqa: E501
from swagger_server.models.vpcs_detach_body import VpcsDetachBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestInstancesController(BaseTestCase):
    """InstancesController integration test stubs"""

    def test_attach_instance_iso(self):
        """Test case for attach_instance_iso

        Attach ISO to Instance
        """
        body = IsoAttachBody()
        response = self.client.open(
            '/v2/instances/{instance-id}/iso/attach'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_attach_instance_network(self):
        """Test case for attach_instance_network

        Attach Private Network to Instance
        """
        body = PrivatenetworksAttachBody()
        response = self.client.open(
            '/v2/instances/{instance-id}/private-networks/attach'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_attach_instance_vpc(self):
        """Test case for attach_instance_vpc

        Attach VPC to Instance
        """
        body = VpcsAttachBody()
        response = self.client.open(
            '/v2/instances/{instance-id}/vpcs/attach'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_instance(self):
        """Test case for create_instance

        Create Instance
        """
        body = InstancesBody()
        response = self.client.open(
            '/v2/instances',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_instance_backup_schedule(self):
        """Test case for create_instance_backup_schedule

        Set Instance Backup Schedule
        """
        body = InstanceidBackupscheduleBody()
        response = self.client.open(
            '/v2/instances/{instance-id}/backup-schedule'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_instance_ipv4(self):
        """Test case for create_instance_ipv4

        Create IPv4
        """
        body = InstanceidIpv4Body()
        response = self.client.open(
            '/v2/instances/{instance-id}/ipv4'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_instance_reverse_ipv4(self):
        """Test case for create_instance_reverse_ipv4

        Create Instance Reverse IPv4
        """
        body = Ipv4ReverseBody()
        response = self.client.open(
            '/v2/instances/{instance-id}/ipv4/reverse'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_instance_reverse_ipv6(self):
        """Test case for create_instance_reverse_ipv6

        Create Instance Reverse IPv6
        """
        body = Ipv6ReverseBody()
        response = self.client.open(
            '/v2/instances/{instance-id}/ipv6/reverse'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_instance(self):
        """Test case for delete_instance

        Delete Instance
        """
        response = self.client.open(
            '/v2/instances/{instance-id}'.format(instance_id='instance_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_instance_ipv4(self):
        """Test case for delete_instance_ipv4

        Delete IPv4 Address
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/ipv4/{ipv4}'.format(instance_id='instance_id_example', ipv4='ipv4_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_instance_reverse_ipv6(self):
        """Test case for delete_instance_reverse_ipv6

        Delete Instance Reverse IPv6
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/ipv6/reverse/{ipv6}'.format(instance_id='instance_id_example', ipv6='ipv6_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_detach_instance_iso(self):
        """Test case for detach_instance_iso

        Detach ISO from instance
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/iso/detach'.format(instance_id='instance_id_example'),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_detach_instance_network(self):
        """Test case for detach_instance_network

        Detach Private Network from Instance.
        """
        body = PrivatenetworksDetachBody()
        response = self.client.open(
            '/v2/instances/{instance-id}/private-networks/detach'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_detach_instance_vpc(self):
        """Test case for detach_instance_vpc

        Detach VPC from Instance
        """
        body = VpcsDetachBody()
        response = self.client.open(
            '/v2/instances/{instance-id}/vpcs/detach'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_instance(self):
        """Test case for get_instance

        Get Instance
        """
        response = self.client.open(
            '/v2/instances/{instance-id}'.format(instance_id='instance_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_instance_backup_schedule(self):
        """Test case for get_instance_backup_schedule

        Get Instance Backup Schedule
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/backup-schedule'.format(instance_id='instance_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_instance_bandwidth(self):
        """Test case for get_instance_bandwidth

        Instance Bandwidth
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/bandwidth'.format(instance_id='instance_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_instance_ipv4(self):
        """Test case for get_instance_ipv4

        List Instance IPv4 Information
        """
        query_string = [('public_network', true),
                        ('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/instances/{instance-id}/ipv4'.format(instance_id='instance_id_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_instance_ipv6(self):
        """Test case for get_instance_ipv6

        Get Instance IPv6 Information
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/ipv6'.format(instance_id='instance_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_instance_iso_status(self):
        """Test case for get_instance_iso_status

        Get Instance ISO Status
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/iso'.format(instance_id='instance_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_instance_neighbors(self):
        """Test case for get_instance_neighbors

        Get Instance neighbors
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/neighbors'.format(instance_id='instance_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_instance_upgrades(self):
        """Test case for get_instance_upgrades

        Get Available Instance Upgrades
        """
        query_string = [('type', 'type_example')]
        response = self.client.open(
            '/v2/instances/{instance-id}/upgrades'.format(instance_id='instance_id_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_instance_userdata(self):
        """Test case for get_instance_userdata

        Get Instance User Data
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/user-data'.format(instance_id='instance_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_halt_instance(self):
        """Test case for halt_instance

        Halt Instance
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/halt'.format(instance_id='instance_id_example'),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_halt_instances(self):
        """Test case for halt_instances

        Halt Instances
        """
        body = InstancesHaltBody()
        response = self.client.open(
            '/v2/instances/halt',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_instance_ipv6_reverse(self):
        """Test case for list_instance_ipv6_reverse

        List Instance IPv6 Reverse
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/ipv6/reverse'.format(instance_id='instance_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_instance_private_networks(self):
        """Test case for list_instance_private_networks

        List instance Private Networks
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/instances/{instance-id}/private-networks'.format(instance_id='instance_id_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_instance_vpcs(self):
        """Test case for list_instance_vpcs

        List instance VPCs
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/instances/{instance-id}/vpcs'.format(instance_id='instance_id_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_instances(self):
        """Test case for list_instances

        List Instances
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example'),
                        ('tag', 'tag_example'),
                        ('label', 'label_example'),
                        ('main_ip', 'main_ip_example'),
                        ('region', 'region_example')]
        response = self.client.open(
            '/v2/instances',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_post_instances_instance_id_ipv4_reverse_default(self):
        """Test case for post_instances_instance_id_ipv4_reverse_default

        Set Default Reverse DNS Entry
        """
        body = ReverseDefaultBody()
        response = self.client.open(
            '/v2/instances/{instance-id}/ipv4/reverse/default'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_reboot_instance(self):
        """Test case for reboot_instance

        Reboot Instance
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/reboot'.format(instance_id='instance_id_example'),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_reboot_instances(self):
        """Test case for reboot_instances

        Reboot instances
        """
        body = InstancesRebootBody()
        response = self.client.open(
            '/v2/instances/reboot',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_reinstall_instance(self):
        """Test case for reinstall_instance

        Reinstall Instance
        """
        body = InstanceidReinstallBody()
        response = self.client.open(
            '/v2/instances/{instance-id}/reinstall'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_restore_instance(self):
        """Test case for restore_instance

        Restore Instance
        """
        body = InstanceidRestoreBody()
        response = self.client.open(
            '/v2/instances/{instance-id}/restore'.format(instance_id='instance_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_start_instance(self):
        """Test case for start_instance

        Start instance
        """
        response = self.client.open(
            '/v2/instances/{instance-id}/start'.format(instance_id='instance_id_example'),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_start_instances(self):
        """Test case for start_instances

        Start instances
        """
        body = InstancesStartBody()
        response = self.client.open(
            '/v2/instances/start',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_instance(self):
        """Test case for update_instance

        Update Instance
        """
        body = InstancesInstanceidBody()
        response = self.client.open(
            '/v2/instances/{instance-id}'.format(instance_id='instance_id_example'),
            method='PATCH',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
