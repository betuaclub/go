# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response20031 import InlineResponse20031  # noqa: E501
from swagger_server.models.inline_response20032 import InlineResponse20032  # noqa: E501
from swagger_server.models.inline_response20033 import InlineResponse20033  # noqa: E501
from swagger_server.models.inline_response2022 import InlineResponse2022  # noqa: E501
from swagger_server.models.loadbalancer_firewall_rule import LoadbalancerFirewallRule  # noqa: E501
from swagger_server.models.loadbalancerid_forwardingrules_body import LoadbalanceridForwardingrulesBody  # noqa: E501
from swagger_server.models.loadbalancers_body import LoadbalancersBody  # noqa: E501
from swagger_server.models.loadbalancers_loadbalancerid_body import LoadbalancersLoadbalanceridBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestLoadBalancerController(BaseTestCase):
    """LoadBalancerController integration test stubs"""

    def test_create_load_balancer(self):
        """Test case for create_load_balancer

        Create Load Balancer
        """
        body = LoadbalancersBody()
        response = self.client.open(
            '/v2/load-balancers',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_load_balancer_forwarding_rules(self):
        """Test case for create_load_balancer_forwarding_rules

        Create Forwarding Rule
        """
        body = LoadbalanceridForwardingrulesBody()
        response = self.client.open(
            '/v2/load-balancers/{load-balancer-id}/forwarding-rules'.format(load_balancer_id='load_balancer_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_load_balancer(self):
        """Test case for delete_load_balancer

        Delete Load Balancer
        """
        response = self.client.open(
            '/v2/load-balancers/{load-balancer-id}'.format(load_balancer_id='load_balancer_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_load_balancer_forwarding_rule(self):
        """Test case for delete_load_balancer_forwarding_rule

        Delete Forwarding Rule
        """
        response = self.client.open(
            '/v2/load-balancers/{load-balancer-id}/forwarding-rules/{forwarding-rule-id}'.format(load_balancer_id='load_balancer_id_example', forwarding_rule_id='forwarding_rule_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_load_balancer(self):
        """Test case for get_load_balancer

        Get Load Balancer
        """
        response = self.client.open(
            '/v2/load-balancers/{load-balancer-id}'.format(load_balancer_id='load_balancer_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_load_balancer_forwarding_rule(self):
        """Test case for get_load_balancer_forwarding_rule

        Get Forwarding Rule
        """
        response = self.client.open(
            '/v2/load-balancers/{load-balancer-id}/forwarding-rules/{forwarding-rule-id}'.format(load_balancer_id='load_balancer_id_example', forwarding_rule_id='forwarding_rule_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_loadbalancer_firewall_rule(self):
        """Test case for get_loadbalancer_firewall_rule

        Get Firewall Rule
        """
        response = self.client.open(
            '/v2/load-balancers/{loadbalancer-id}/firewall-rules/{firewall-rule-id}'.format(loadbalancer_id='loadbalancer_id_example', firewall_rule_id='firewall_rule_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_load_balancer_forwarding_rules(self):
        """Test case for list_load_balancer_forwarding_rules

        List Forwarding Rules
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/load-balancers/{load-balancer-id}/forwarding-rules'.format(load_balancer_id='load_balancer_id_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_load_balancers(self):
        """Test case for list_load_balancers

        List Load Balancers
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/load-balancers',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_loadbalancer_firewall_rules(self):
        """Test case for list_loadbalancer_firewall_rules

        List Firewall Rules
        """
        query_string = [('per_page', 'per_page_example'),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/load-balancers/{loadbalancer-id}/firewall-rules'.format(loadbalancer_id='loadbalancer_id_example'),
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_load_balancer(self):
        """Test case for update_load_balancer

        Update Load Balancer
        """
        body = LoadbalancersLoadbalanceridBody()
        response = self.client.open(
            '/v2/load-balancers/{load-balancer-id}'.format(load_balancer_id='load_balancer_id_example'),
            method='PATCH',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
