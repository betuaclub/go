# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.clusters_vkeid_body import ClustersVkeidBody  # noqa: E501
from swagger_server.models.inline_response20054 import InlineResponse20054  # noqa: E501
from swagger_server.models.inline_response20055 import InlineResponse20055  # noqa: E501
from swagger_server.models.inline_response20056 import InlineResponse20056  # noqa: E501
from swagger_server.models.inline_response20057 import InlineResponse20057  # noqa: E501
from swagger_server.models.inline_response20058 import InlineResponse20058  # noqa: E501
from swagger_server.models.inline_response20059 import InlineResponse20059  # noqa: E501
from swagger_server.models.inline_response2015 import InlineResponse2015  # noqa: E501
from swagger_server.models.inline_response2016 import InlineResponse2016  # noqa: E501
from swagger_server.models.kubernetes_clusters_body import KubernetesClustersBody  # noqa: E501
from swagger_server.models.nodepools_nodepoolid_body import NodepoolsNodepoolidBody  # noqa: E501
from swagger_server.models.nodepools_nodepoolid_body1 import NodepoolsNodepoolidBody1  # noqa: E501
from swagger_server.models.vkeid_nodepools_body import VkeidNodepoolsBody  # noqa: E501
from swagger_server.models.vkeid_upgrades_body import VkeidUpgradesBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestKubernetesController(BaseTestCase):
    """KubernetesController integration test stubs"""

    def test_create_kubernetes_cluster(self):
        """Test case for create_kubernetes_cluster

        Create Kubernetes Cluster
        """
        body = KubernetesClustersBody()
        response = self.client.open(
            '/v2/kubernetes/clusters',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_nodepools(self):
        """Test case for create_nodepools

        Create NodePool
        """
        body = VkeidNodepoolsBody()
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/node-pools'.format(vke_id='vke_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_kubernetes_cluster(self):
        """Test case for delete_kubernetes_cluster

        Delete Kubernetes Cluster
        """
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}'.format(vke_id='vke_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_kubernetes_cluster_vke_id_delete_with_linked_resources(self):
        """Test case for delete_kubernetes_cluster_vke_id_delete_with_linked_resources

        Delete VKE Cluster and All Related Resources
        """
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/delete-with-linked-resources'.format(vke_id='vke_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_nodepool(self):
        """Test case for delete_nodepool

        Delete Nodepool
        """
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/node-pools/{nodepool-id}'.format(vke_id='vke_id_example', nodepool_id='nodepool_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_nodepool_instance(self):
        """Test case for delete_nodepool_instance

        Delete NodePool Instance
        """
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/node-pools/{nodepool-id}/nodes/{node-id}'.format(vke_id='vke_id_example', nodepool_id='nodepool_id_example', node_id='node_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_kubernetes_available_upgrades(self):
        """Test case for get_kubernetes_available_upgrades

        Get Kubernetes Available Upgrades
        """
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/available-upgrades'.format(vke_id='vke_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_kubernetes_clusters(self):
        """Test case for get_kubernetes_clusters

        Get Kubernetes Cluster
        """
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}'.format(vke_id='vke_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_kubernetes_clusters_config(self):
        """Test case for get_kubernetes_clusters_config

        Get Kubernetes Cluster Kubeconfig
        """
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/config'.format(vke_id='vke_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_kubernetes_resources(self):
        """Test case for get_kubernetes_resources

        Get Kubernetes Resources
        """
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/resources'.format(vke_id='vke_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_kubernetes_versions(self):
        """Test case for get_kubernetes_versions

        Get Kubernetes Versions
        """
        response = self.client.open(
            '/v2/kubernetes/versions',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_nodepool(self):
        """Test case for get_nodepool

        Get NodePool
        """
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/node-pools/{nodepool-id}'.format(vke_id='vke_id_example', nodepool_id='nodepool_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_nodepools(self):
        """Test case for get_nodepools

        List NodePools
        """
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/node-pools'.format(vke_id='vke_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_kubernetes_clusters(self):
        """Test case for list_kubernetes_clusters

        List all Kubernetes Clusters
        """
        response = self.client.open(
            '/v2/kubernetes/clusters',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_recycle_nodepool_instance(self):
        """Test case for recycle_nodepool_instance

        Recycle a NodePool Instance
        """
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/node-pools/{nodepool-id}/nodes/{node-id}/recycle'.format(vke_id='vke_id_example', nodepool_id='nodepool_id_example', node_id='node_id_example'),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_start_kubernetes_cluster_upgrade(self):
        """Test case for start_kubernetes_cluster_upgrade

        Start Kubernetes Cluster Upgrade
        """
        body = VkeidUpgradesBody()
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/upgrades'.format(vke_id='vke_id_example'),
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_kubernetes_cluster(self):
        """Test case for update_kubernetes_cluster

        Update Kubernetes Cluster
        """
        body = ClustersVkeidBody()
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}'.format(vke_id='vke_id_example'),
            method='PUT',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_nodepool(self):
        """Test case for update_nodepool

        Update Nodepool
        """
        body = NodepoolsNodepoolidBody1()
        response = self.client.open(
            '/v2/kubernetes/clusters/{vke-id}/node-pools/{nodepool-id}'.format(vke_id='vke_id_example', nodepool_id='nodepool_id_example'),
            method='PATCH',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
