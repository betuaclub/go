# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response20020 import InlineResponse20020  # noqa: E501
from swagger_server.models.inline_response20021 import InlineResponse20021  # noqa: E501
from swagger_server.models.inline_response2012 import InlineResponse2012  # noqa: E501
from swagger_server.models.iso_body import IsoBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestIsoController(BaseTestCase):
    """IsoController integration test stubs"""

    def test_create_iso(self):
        """Test case for create_iso

        Create ISO
        """
        body = IsoBody()
        response = self.client.open(
            '/v2/iso',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_iso(self):
        """Test case for delete_iso

        Delete ISO
        """
        response = self.client.open(
            '/v2/iso/{iso-id}'.format(iso_id='iso_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_iso_get(self):
        """Test case for iso_get

        Get ISO
        """
        response = self.client.open(
            '/v2/iso/{iso-id}'.format(iso_id='iso_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_isos(self):
        """Test case for list_isos

        List ISOs
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/iso',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_public_isos(self):
        """Test case for list_public_isos

        List Public ISOs
        """
        response = self.client.open(
            '/v2/iso-public',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
