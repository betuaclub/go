# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response2002 import InlineResponse2002  # noqa: E501
from swagger_server.models.inline_response2003 import InlineResponse2003  # noqa: E501
from swagger_server.models.vpcs_body import VpcsBody  # noqa: E501
from swagger_server.models.vpcs_vpcid_body import VpcsVpcidBody  # noqa: E501
from swagger_server.test import BaseTestCase


class TestVPCsController(BaseTestCase):
    """VPCsController integration test stubs"""

    def test_create_vpc(self):
        """Test case for create_vpc

        Create a VPC
        """
        body = VpcsBody()
        response = self.client.open(
            '/v2/vpcs',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_vpc(self):
        """Test case for delete_vpc

        Delete a VPC
        """
        response = self.client.open(
            '/v2/vpcs/{vpc-id}'.format(vpc_id='vpc_id_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_vpc(self):
        """Test case for get_vpc

        Get a VPC
        """
        response = self.client.open(
            '/v2/vpcs/{vpc-id}'.format(vpc_id='vpc_id_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_list_vpcs(self):
        """Test case for list_vpcs

        List VPCs
        """
        query_string = [('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/vpcs',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_vpc(self):
        """Test case for update_vpc

        Update a VPC
        """
        body = VpcsVpcidBody()
        response = self.client.open(
            '/v2/vpcs/{vpc-id}'.format(vpc_id='vpc_id_example'),
            method='PUT',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
