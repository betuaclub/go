# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.inline_response20014 import InlineResponse20014  # noqa: E501
from swagger_server.test import BaseTestCase


class TestApplicationController(BaseTestCase):
    """ApplicationController integration test stubs"""

    def test_list_applications(self):
        """Test case for list_applications

        List Applications
        """
        query_string = [('type', 'type_example'),
                        ('per_page', 56),
                        ('cursor', 'cursor_example')]
        response = self.client.open(
            '/v2/applications',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
