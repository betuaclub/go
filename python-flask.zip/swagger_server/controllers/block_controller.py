import connexion
import six

from swagger_server.models.blockid_attach_body import BlockidAttachBody  # noqa: E501
from swagger_server.models.blockid_detach_body import BlockidDetachBody  # noqa: E501
from swagger_server.models.blocks_blockid_body import BlocksBlockidBody  # noqa: E501
from swagger_server.models.blocks_body import BlocksBody  # noqa: E501
from swagger_server.models.inline_response20017 import InlineResponse20017  # noqa: E501
from swagger_server.models.inline_response202 import InlineResponse202  # noqa: E501
from swagger_server import util


def attach_block(block_id, body=None):  # noqa: E501
    """Attach Block Storage

    Attach Block Storage to Instance &#x60;instance_id&#x60;. # noqa: E501

    :param block_id: The [Block Storage id](#operation/list-blocks).
    :type block_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = BlockidAttachBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def create_block(body=None):  # noqa: E501
    """Create Block Storage

    Create new Block Storage in a &#x60;region&#x60; with a size of &#x60;size_gb&#x60;. Size may range between 10 and 40000 depending on the &#x60;block_type&#x60;. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse202
    """
    if connexion.request.is_json:
        body = BlocksBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_block(block_id):  # noqa: E501
    """Delete Block Storage

    Delete Block Storage. # noqa: E501

    :param block_id: The [Block Storage id](#operation/list-blocks).
    :type block_id: str

    :rtype: None
    """
    return 'do some magic!'


def detach_block(block_id, body=None):  # noqa: E501
    """Detach Block Storage

    Detach Block Storage. # noqa: E501

    :param block_id: The [Block Storage id](#operation/list-blocks).
    :type block_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = BlockidDetachBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def get_block(block_id):  # noqa: E501
    """Get Block Storage

    Get information for Block Storage. # noqa: E501

    :param block_id: The [Block Storage id](#operation/list-blocks).
    :type block_id: str

    :rtype: InlineResponse202
    """
    return 'do some magic!'


def list_blocks(per_page=None, cursor=None):  # noqa: E501
    """List Block storages

    List all Block Storage in your account. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20017
    """
    return 'do some magic!'


def update_block(block_id, body=None):  # noqa: E501
    """Update Block Storage

    Update information for Block Storage.  # noqa: E501

    :param block_id: The [Block Storage id](#operation/list-blocks).
    :type block_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = BlocksBlockidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
