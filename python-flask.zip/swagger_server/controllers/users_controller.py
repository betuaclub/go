import connexion
import six

from swagger_server.models.inline_response2004 import InlineResponse2004  # noqa: E501
from swagger_server.models.user import User  # noqa: E501
from swagger_server.models.users_body import UsersBody  # noqa: E501
from swagger_server.models.users_userid_body import UsersUseridBody  # noqa: E501
from swagger_server import util


def create_user(body=None):  # noqa: E501
    """Create User

    Create a new User. The &#x60;email&#x60;, &#x60;name&#x60;, and &#x60;password&#x60; attributes are required. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: User
    """
    if connexion.request.is_json:
        body = UsersBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_user(user_id):  # noqa: E501
    """Delete User

    Delete a User. # noqa: E501

    :param user_id: The [User id](#operation/list-users).
    :type user_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_user(user_id):  # noqa: E501
    """Get User

    Get information about a User. # noqa: E501

    :param user_id: The [User id](#operation/list-users).
    :type user_id: str

    :rtype: User
    """
    return 'do some magic!'


def list_users(per_page=None, cursor=None):  # noqa: E501
    """Get Users

    Get a list of all Users in your account. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: float
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse2004
    """
    return 'do some magic!'


def update_user(user_id, body=None):  # noqa: E501
    """Update User

    Update information for a User. All attributes are optional. If not set, the attributes will retain their original values. # noqa: E501

    :param user_id: The [User id](#operation/list-users).
    :type user_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = UsersUseridBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
