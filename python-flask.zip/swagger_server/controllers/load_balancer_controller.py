import connexion
import six

from swagger_server.models.inline_response20031 import InlineResponse20031  # noqa: E501
from swagger_server.models.inline_response20032 import InlineResponse20032  # noqa: E501
from swagger_server.models.inline_response20033 import InlineResponse20033  # noqa: E501
from swagger_server.models.inline_response2022 import InlineResponse2022  # noqa: E501
from swagger_server.models.loadbalancer_firewall_rule import LoadbalancerFirewallRule  # noqa: E501
from swagger_server.models.loadbalancerid_forwardingrules_body import LoadbalanceridForwardingrulesBody  # noqa: E501
from swagger_server.models.loadbalancers_body import LoadbalancersBody  # noqa: E501
from swagger_server.models.loadbalancers_loadbalancerid_body import LoadbalancersLoadbalanceridBody  # noqa: E501
from swagger_server import util


def create_load_balancer(body=None):  # noqa: E501
    """Create Load Balancer

    Create a new Load Balancer in a particular &#x60;region&#x60;. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2022
    """
    if connexion.request.is_json:
        body = LoadbalancersBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def create_load_balancer_forwarding_rules(load_balancer_id, body=None):  # noqa: E501
    """Create Forwarding Rule

    Create a new forwarding rule for a Load Balancer. # noqa: E501

    :param load_balancer_id: The [Load Balancer id](#operation/list-load-balancers).
    :type load_balancer_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = LoadbalanceridForwardingrulesBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_load_balancer(load_balancer_id):  # noqa: E501
    """Delete Load Balancer

    Delete a Load Balancer. # noqa: E501

    :param load_balancer_id: The [Load Balancer id](#operation/list-load-balancers).
    :type load_balancer_id: str

    :rtype: None
    """
    return 'do some magic!'


def delete_load_balancer_forwarding_rule(load_balancer_id, forwarding_rule_id):  # noqa: E501
    """Delete Forwarding Rule

    Delete a Forwarding Rule on a Load Balancer. # noqa: E501

    :param load_balancer_id: The [Load Balancer id](#operation/list-load-balancers).
    :type load_balancer_id: str
    :param forwarding_rule_id: The [Forwarding Rule id](#operation/list-load-balancer-forwarding-rules).
    :type forwarding_rule_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_load_balancer(load_balancer_id):  # noqa: E501
    """Get Load Balancer

    Get information for a Load Balancer. # noqa: E501

    :param load_balancer_id: The [Load Balancer id](#operation/list-load-balancers).
    :type load_balancer_id: str

    :rtype: InlineResponse2022
    """
    return 'do some magic!'


def get_load_balancer_forwarding_rule(load_balancer_id, forwarding_rule_id):  # noqa: E501
    """Get Forwarding Rule

    Get information for a Forwarding Rule on a Load Balancer. # noqa: E501

    :param load_balancer_id: The [Load Balancer id](#operation/list-load-balancers).
    :type load_balancer_id: str
    :param forwarding_rule_id: The [Forwarding Rule id](#operation/list-load-balancer-forwarding-rules).
    :type forwarding_rule_id: str

    :rtype: InlineResponse20033
    """
    return 'do some magic!'


def get_loadbalancer_firewall_rule(loadbalancer_id, firewall_rule_id):  # noqa: E501
    """Get Firewall Rule

    Get a firewall rule for a Load Balancer. # noqa: E501

    :param loadbalancer_id: 
    :type loadbalancer_id: str
    :param firewall_rule_id: 
    :type firewall_rule_id: str

    :rtype: LoadbalancerFirewallRule
    """
    return 'do some magic!'


def list_load_balancer_forwarding_rules(load_balancer_id, per_page=None, cursor=None):  # noqa: E501
    """List Forwarding Rules

    List the fowarding rules for a Load Balancer. # noqa: E501

    :param load_balancer_id: The [Load Balancer id](#operation/list-load-balancers).
    :type load_balancer_id: str
    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20032
    """
    return 'do some magic!'


def list_load_balancers(per_page=None, cursor=None):  # noqa: E501
    """List Load Balancers

    List the Load Balancers in your account. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500. 
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20031
    """
    return 'do some magic!'


def list_loadbalancer_firewall_rules(loadbalancer_id, per_page=None, cursor=None):  # noqa: E501
    """List Firewall Rules

    List the firewall rules for a Load Balancer. # noqa: E501

    :param loadbalancer_id: 
    :type loadbalancer_id: str
    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: str
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: LoadbalancerFirewallRule
    """
    return 'do some magic!'


def update_load_balancer(load_balancer_id, body=None):  # noqa: E501
    """Update Load Balancer

    Update information for a Load Balancer. All attributes are optional. If not set, the attributes will retain their original values. # noqa: E501

    :param load_balancer_id: The [Load Balancer id](#operation/list-load-balancers).
    :type load_balancer_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = LoadbalancersLoadbalanceridBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
