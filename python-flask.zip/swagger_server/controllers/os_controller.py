import connexion
import six

from swagger_server.models.inline_response20013 import InlineResponse20013  # noqa: E501
from swagger_server import util


def list_os(per_page=None, cursor=None):  # noqa: E501
    """List OS

    List the OS images available for installation at Vultr. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500. 
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20013
    """
    return 'do some magic!'
