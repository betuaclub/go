import connexion
import six

from swagger_server.models.inline_response20011 import InlineResponse20011  # noqa: E501
from swagger_server.models.inline_response20012 import InlineResponse20012  # noqa: E501
from swagger_server.models.reservedip_attach_body import ReservedipAttachBody  # noqa: E501
from swagger_server.models.reservedips_body import ReservedipsBody  # noqa: E501
from swagger_server.models.reservedips_convert_body import ReservedipsConvertBody  # noqa: E501
from swagger_server.models.reservedips_reservedip_body import ReservedipsReservedipBody  # noqa: E501
from swagger_server import util


def attach_reserved_ip(reserved_ip, body=None):  # noqa: E501
    """Attach Reserved IP

    Attach a Reserved IP to an compute instance or a baremetal instance - &#x60;instance_id&#x60;. # noqa: E501

    :param reserved_ip: The [Reserved IP id](#operation/list-reserved-ips)
    :type reserved_ip: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = ReservedipAttachBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def convert_reserved_ip(body=None):  # noqa: E501
    """Convert Instance IP to Reserved IP

    Convert the &#x60;ip_address&#x60; of an existing [instance](#operation/list-instances) into a Reserved IP. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse20011
    """
    if connexion.request.is_json:
        body = ReservedipsConvertBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def create_reserved_ip(body=None):  # noqa: E501
    """Create Reserved IP

    Create a new Reserved IP. The &#x60;region&#x60; and &#x60;ip_type&#x60; attributes are required. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse20011
    """
    if connexion.request.is_json:
        body = ReservedipsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_reserved_ip(reserved_ip):  # noqa: E501
    """Delete Reserved IP

    Delete a Reserved IP. # noqa: E501

    :param reserved_ip: The [Reserved IP id](#operation/list-reserved-ips).
    :type reserved_ip: str

    :rtype: None
    """
    return 'do some magic!'


def detach_reserved_ip(reserved_ip):  # noqa: E501
    """Detach Reserved IP

    Detach a Reserved IP. # noqa: E501

    :param reserved_ip: The [Reserved IP id](#operation/list-reserved-ips)
    :type reserved_ip: str

    :rtype: None
    """
    return 'do some magic!'


def get_reserved_ip(reserved_ip):  # noqa: E501
    """Get Reserved IP

    Get information about a Reserved IP. # noqa: E501

    :param reserved_ip: The [Reserved IP id](#operation/list-reserved-ips).
    :type reserved_ip: str

    :rtype: InlineResponse20011
    """
    return 'do some magic!'


def list_reserved_ips(per_page=None, cursor=None):  # noqa: E501
    """List Reserved IPs

    List all Reserved IPs in your account. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20012
    """
    return 'do some magic!'


def patch_reserved_ips_reserved_ip(reserved_ip, body=None):  # noqa: E501
    """Update Reserved IP

    Update information on a Reserved IP. # noqa: E501

    :param reserved_ip: The [Reserved IP id](#operation/list-reserved-ips).
    :type reserved_ip: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse20011
    """
    if connexion.request.is_json:
        body = ReservedipsReservedipBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
