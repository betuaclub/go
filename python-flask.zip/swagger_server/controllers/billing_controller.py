import connexion
import six

from swagger_server.models.inline_response20060 import InlineResponse20060  # noqa: E501
from swagger_server.models.inline_response20061 import InlineResponse20061  # noqa: E501
from swagger_server.models.inline_response20062 import InlineResponse20062  # noqa: E501
from swagger_server.models.inline_response20063 import InlineResponse20063  # noqa: E501
from swagger_server import util


def get_invoice(invoice_id):  # noqa: E501
    """Get Invoice

    Retrieve specified invoice # noqa: E501

    :param invoice_id: ID of invoice
    :type invoice_id: str

    :rtype: InlineResponse20062
    """
    return 'do some magic!'


def get_invoice_items(invoice_id):  # noqa: E501
    """Get Invoice Items

    Retrieve full specified invoice # noqa: E501

    :param invoice_id: ID of invoice
    :type invoice_id: str

    :rtype: InlineResponse20063
    """
    return 'do some magic!'


def list_billing_history():  # noqa: E501
    """List Billing History

    Retrieve list of billing history # noqa: E501


    :rtype: InlineResponse20060
    """
    return 'do some magic!'


def list_invoices():  # noqa: E501
    """List Invoices

    Retrieve a list of invoices # noqa: E501


    :rtype: InlineResponse20061
    """
    return 'do some magic!'
