import connexion
import six

from swagger_server.models.inline_response20029 import InlineResponse20029  # noqa: E501
from swagger_server.models.inline_response20030 import InlineResponse20030  # noqa: E501
from swagger_server import util


def list_available_plans_region(region_id, type=None):  # noqa: E501
    """List available plans in region

    Get a list of the available plans in Region &#x60;region-id&#x60;. Not all plans are available in all regions. # noqa: E501

    :param region_id: The [Region id](#operation/list-regions).
    :type region_id: str
    :param type: Filter the results by type.  | **Type** | **Description** | |----------|-----------------| | all | All available types | | vc2 | Cloud Compute | | vdc | Dedicated Cloud | | vhf | High Frequency Compute | | vhp | High Performance | | voc | All Optimized Cloud types | | voc-g | General Purpose Optimized Cloud | | voc-c | CPU Optimized Cloud | | voc-m | Memory Optimized Cloud | | voc-s | Storage Optimized Cloud | | vbm | Bare Metal | | vcg | Cloud GPU | 
    :type type: str

    :rtype: InlineResponse20030
    """
    return 'do some magic!'


def list_regions(per_page=None, cursor=None):  # noqa: E501
    """List Regions

    List all Regions at Vultr. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20029
    """
    return 'do some magic!'
