import connexion
import six

from swagger_server.models.inline_response20020 import InlineResponse20020  # noqa: E501
from swagger_server.models.inline_response20021 import InlineResponse20021  # noqa: E501
from swagger_server.models.inline_response2012 import InlineResponse2012  # noqa: E501
from swagger_server.models.iso_body import IsoBody  # noqa: E501
from swagger_server import util


def create_iso(body=None):  # noqa: E501
    """Create ISO

    Create a new ISO in your account from &#x60;url&#x60;. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2012
    """
    if connexion.request.is_json:
        body = IsoBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_iso(iso_id):  # noqa: E501
    """Delete ISO

    Delete an ISO. # noqa: E501

    :param iso_id: The [ISO id](#operation/list-isos).
    :type iso_id: str

    :rtype: None
    """
    return 'do some magic!'


def iso_get(iso_id):  # noqa: E501
    """Get ISO

    Get information for an ISO. # noqa: E501

    :param iso_id: The [ISO id](#operation/list-isos).
    :type iso_id: str

    :rtype: InlineResponse2012
    """
    return 'do some magic!'


def list_isos(per_page=None, cursor=None):  # noqa: E501
    """List ISOs

    Get the ISOs in your account. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20020
    """
    return 'do some magic!'


def list_public_isos():  # noqa: E501
    """List Public ISOs

    List all Vultr Public ISOs. # noqa: E501


    :rtype: InlineResponse20021
    """
    return 'do some magic!'
