import connexion
import six

from swagger_server.models.inline_response2005 import InlineResponse2005  # noqa: E501
from swagger_server.models.inline_response2006 import InlineResponse2006  # noqa: E501
from swagger_server.models.startupscripts_body import StartupscriptsBody  # noqa: E501
from swagger_server.models.startupscripts_startupid_body import StartupscriptsStartupidBody  # noqa: E501
from swagger_server import util


def create_startup_script(body=None):  # noqa: E501
    """Create Startup Script

    Create a new Startup Script. The &#x60;name&#x60; and &#x60;script&#x60; attributes are required, and scripts are base-64 encoded. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2005
    """
    if connexion.request.is_json:
        body = StartupscriptsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_startup_script(startup_id):  # noqa: E501
    """Delete Startup Script

    Delete a Startup Script. # noqa: E501

    :param startup_id: The [Startup Script id](#operation/list-startup-scripts).
    :type startup_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_startup_script(startup_id):  # noqa: E501
    """Get Startup Script

    Get information for a Startup Script. # noqa: E501

    :param startup_id: The [Startup Script id](#operation/list-startup-scripts).
    :type startup_id: str

    :rtype: InlineResponse2005
    """
    return 'do some magic!'


def list_startup_scripts(per_page=None, cursor=None):  # noqa: E501
    """List Startup Scripts

    Get a list of all Startup Scripts. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse2006
    """
    return 'do some magic!'


def update_startup_script(startup_id, body=None):  # noqa: E501
    """Update Startup Script

    Update a Startup Script. The attributes &#x60;name&#x60; and &#x60;script&#x60; are optional. If not set, the attributes will retain their original values. The &#x60;script&#x60; attribute is base-64 encoded. New deployments will use the updated script, but this action does not update previously deployed instances. # noqa: E501

    :param startup_id: The [Startup Script id](#operation/list-startup-scripts).
    :type startup_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = StartupscriptsStartupidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
