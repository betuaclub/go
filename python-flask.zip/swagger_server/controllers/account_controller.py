import connexion
import six

from swagger_server.models.inline_response20015 import InlineResponse20015  # noqa: E501
from swagger_server import util


def get_account():  # noqa: E501
    """Get Account Info

    Get your Vultr account, permission, and billing information. # noqa: E501


    :rtype: InlineResponse20015
    """
    return 'do some magic!'
