import connexion
import six

from swagger_server.models.baremetals_baremetalid_body import BaremetalsBaremetalidBody  # noqa: E501
from swagger_server.models.baremetals_body import BaremetalsBody  # noqa: E501
from swagger_server.models.baremetals_halt_body import BaremetalsHaltBody  # noqa: E501
from swagger_server.models.baremetals_reboot_body import BaremetalsRebootBody  # noqa: E501
from swagger_server.models.baremetals_start_body import BaremetalsStartBody  # noqa: E501
from swagger_server.models.inline_response20036 import InlineResponse20036  # noqa: E501
from swagger_server.models.inline_response20037 import InlineResponse20037  # noqa: E501
from swagger_server.models.inline_response20038 import InlineResponse20038  # noqa: E501
from swagger_server.models.inline_response20039 import InlineResponse20039  # noqa: E501
from swagger_server.models.inline_response20040 import InlineResponse20040  # noqa: E501
from swagger_server.models.inline_response20041 import InlineResponse20041  # noqa: E501
from swagger_server.models.inline_response20052 import InlineResponse20052  # noqa: E501
from swagger_server.models.inline_response20053 import InlineResponse20053  # noqa: E501
from swagger_server.models.inline_response2023 import InlineResponse2023  # noqa: E501
from swagger_server import util


def create_baremetal(body=None):  # noqa: E501
    """Create Bare Metal Instance

    Create a new Bare Metal instance in a &#x60;region&#x60; with the desired &#x60;plan&#x60;. Choose one of the following to deploy the instance:  * &#x60;os_id&#x60; * &#x60;snapshot_id&#x60; * &#x60;app_id&#x60; * &#x60;image_id&#x60;  Supply other attributes as desired. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse2023
    """
    if connexion.request.is_json:
        body = BaremetalsBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def delete_baremetal(baremetal_id):  # noqa: E501
    """Delete Bare Metal

    Delete a Bare Metal instance. # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str

    :rtype: None
    """
    return 'do some magic!'


def get_bandwidth_baremetal(baremetal_id):  # noqa: E501
    """Bare Metal Bandwidth

    Get bandwidth information for the Bare Metal instance.&lt;br&gt;&lt;br&gt;The &#x60;bandwidth&#x60; object in a successful response contains objects representing a day in the month. The date is denoted by the nested object keys. Days begin and end in the UTC timezone. Bandwidth utilization data contained within the date object is refreshed periodically. We do not recommend using this endpoint to gather real-time metrics. # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str

    :rtype: InlineResponse20040
    """
    return 'do some magic!'


def get_bare_metal_userdata(baremetal_id):  # noqa: E501
    """Get Bare Metal User Data

    Get the user-supplied, base64 encoded [user data](https://www.vultr.com/docs/manage-instance-user-data-with-the-vultr-metadata-api/) for a Bare Metal. # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str

    :rtype: InlineResponse20041
    """
    return 'do some magic!'


def get_bare_metal_vnc(baremetal_id):  # noqa: E501
    """Get VNC URL for a Bare Metal

    Get the VNC URL for a Bare Metal # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str

    :rtype: InlineResponse20053
    """
    return 'do some magic!'


def get_bare_metals_upgrades(baremetal_id, type=None):  # noqa: E501
    """Get Available Bare Metal Upgrades

    Get available upgrades for a Bare Metal # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str
    :param type: Filter upgrade by type:  - all (applications, plans) - applications - os
    :type type: str

    :rtype: InlineResponse20052
    """
    return 'do some magic!'


def get_baremetal(baremetal_id):  # noqa: E501
    """Get Bare Metal

    Get information for a Bare Metal instance. # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str

    :rtype: InlineResponse20037
    """
    return 'do some magic!'


def get_ipv4_baremetal(baremetal_id):  # noqa: E501
    """Bare Metal IPv4 Addresses

    Get the IPv4 information for the Bare Metal instance. # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str

    :rtype: InlineResponse20038
    """
    return 'do some magic!'


def get_ipv6_baremetal(baremetal_id):  # noqa: E501
    """Bare Metal IPv6 Addresses

    Get the IPv6 information for the Bare Metal instance. # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str

    :rtype: InlineResponse20039
    """
    return 'do some magic!'


def halt_baremetal(baremetal_id):  # noqa: E501
    """Halt Bare Metal

    Halt the Bare Metal instance. # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str

    :rtype: None
    """
    return 'do some magic!'


def halt_baremetals(body=None):  # noqa: E501
    """Halt Bare Metals

    Halt Bare Metals. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = BaremetalsHaltBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def list_baremetals(per_page=None, cursor=None):  # noqa: E501
    """List Bare Metal Instances

    List all Bare Metal instances in your account. # noqa: E501

    :param per_page: Number of items requested per page. Default is 100 and Max is 500. 
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20036
    """
    return 'do some magic!'


def reboot_bare_metals(body=None):  # noqa: E501
    """Reboot Bare Metals

    Reboot Bare Metals. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = BaremetalsRebootBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def reboot_baremetal(baremetal_id):  # noqa: E501
    """Reboot Bare Metal

    Reboot the Bare Metal instance. # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str

    :rtype: None
    """
    return 'do some magic!'


def reinstall_baremetal(baremetal_id):  # noqa: E501
    """Reinstall Bare Metal

    Reinstall the Bare Metal instance.  **Note:** This action may take a few extra seconds to complete. # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str

    :rtype: InlineResponse20037
    """
    return 'do some magic!'


def start_bare_metals(body=None):  # noqa: E501
    """Start Bare Metals

    Start Bare Metals. # noqa: E501

    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = BaremetalsStartBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def start_baremetal(baremetal_id):  # noqa: E501
    """Start Bare Metal

    Start the Bare Metal instance. # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str

    :rtype: None
    """
    return 'do some magic!'


def update_baremetal(baremetal_id, body=None):  # noqa: E501
    """Update Bare Metal

    Update a Bare Metal instance. All attributes are optional. If not set, the attributes will retain their original values.  **Note:** Changing &#x60;os_id&#x60;, &#x60;app_id&#x60; or &#x60;image_id&#x60; may take a few extra seconds to complete. # noqa: E501

    :param baremetal_id: The [Bare Metal id](#operation/list-baremetals).
    :type baremetal_id: str
    :param body: Include a JSON object in the request body with a content type of **application/json**.
    :type body: dict | bytes

    :rtype: InlineResponse20037
    """
    if connexion.request.is_json:
        body = BaremetalsBaremetalidBody.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
