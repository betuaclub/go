import connexion
import six

from swagger_server.models.inline_response20014 import InlineResponse20014  # noqa: E501
from swagger_server import util


def list_applications(type=None, per_page=None, cursor=None):  # noqa: E501
    """List Applications

    Get a list of all available Applications. # noqa: E501

    :param type: Filter the results by type.  |   | Type | Description | | - | ------ | ------------- | |   | all | All available application types | |   | marketplace | Marketplace applications | |   | one-click | Vultr One-Click applications |
    :type type: str
    :param per_page: Number of items requested per page. Default is 100 and Max is 500.
    :type per_page: int
    :param cursor: Cursor for paging. See [Meta and Pagination](#section/Introduction/Meta-and-Pagination).
    :type cursor: str

    :rtype: InlineResponse20014
    """
    return 'do some magic!'
